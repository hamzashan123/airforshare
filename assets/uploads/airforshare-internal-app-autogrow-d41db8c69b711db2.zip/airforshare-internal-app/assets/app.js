import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.5/firebase-app.js";
import {
  getFirestore,
  doc,
  collection,
  onSnapshot,
  setDoc,
  deleteDoc,
  addDoc,
  getDocs,
  serverTimestamp,
  query,
  orderBy
} from "https://www.gstatic.com/firebasejs/10.12.5/firebase-firestore.js";

const firebaseConfig = {
  apiKey: "AIzaSyD2C-FbviUciXjiFTQQ1yhPt1g8Fptnfgg",
  authDomain: "airforshare-b2066.firebaseapp.com",
  projectId: "airforshare-b2066",
  storageBucket: "airforshare-b2066.firebasestorage.app",
  messagingSenderId: "764213503496",
  appId: "1:764213503496:web:e50e1dd4120dd1af8813bd"
};

const app = initializeApp(firebaseConfig);
const db = getFirestore(app);
const textDocRef = doc(db, "internal_share", "text");
const filesColRef = collection(db, "internal_share", "attachments", "items");

const $ = (selector) => document.querySelector(selector);
const textArea = $("#sharedText");
const saveTextBtn = $("#saveTextBtn");
const saveState = $("#saveState");
const copyBtn = $("#copyBtn");
const clearTextBtn = $("#clearTextBtn");
const fileInput = $("#fileInput");
const dropzone = $("#dropzone");
const saveFilesBtn = $("#saveFilesBtn");
const selectedFiles = $("#selectedFiles");
const uploadState = $("#uploadState");
const uploadProgress = $("#uploadProgress");
const uploadProgressBar = $("#uploadProgressBar");
const fileList = $("#fileList");
const clearFilesBtn = $("#clearFilesBtn");
const toast = $("#toast");

let isSavingText = false;
let pendingFiles = [];
const renderedFiles = new Map();

function autoGrowTextArea() {
  textArea.style.height = "auto";
  textArea.style.height = `${textArea.scrollHeight}px`;
}

textArea.addEventListener("input", autoGrowTextArea);
window.addEventListener("resize", autoGrowTextArea);

function showToast(message) {
  toast.textContent = message;
  toast.classList.add("show");
  setTimeout(() => toast.classList.remove("show"), 2200);
}

function setStatus(message = "", className = "") {
  saveState.textContent = message;
  saveState.className = `save-state ${className}`.trim();
}

function hideStatusSoon() {
  setTimeout(() => setStatus(""), 900);
}

function setUploadStatus(message = "", className = "") {
  uploadState.textContent = message;
  uploadState.className = `upload-state ${className}`.trim();
}

function setUploadProgress(percent = 0, visible = true) {
  const safePercent = Math.max(0, Math.min(100, Math.round(percent)));
  uploadProgress.hidden = !visible;
  uploadProgressBar.style.width = `${safePercent}%`;
}

function hideUploadProgressSoon() {
  setTimeout(() => {
    setUploadStatus("");
    setUploadProgress(0, false);
  }, 900);
}

function bytesToSize(bytes) {
  if (!bytes) return "0 B";
  const units = ["B", "KB", "MB", "GB"];
  const i = Math.floor(Math.log(bytes) / Math.log(1024));
  return `${(bytes / Math.pow(1024, i)).toFixed(i ? 1 : 0)} ${units[i]}`;
}

function getFileExtension(name = "") {
  const cleanName = String(name).split("?")[0];
  const parts = cleanName.split(".");
  return parts.length > 1 ? parts.pop().toUpperCase().slice(0, 8) : "FILE";
}

function isImageFile(file = {}) {
  const type = file.type || "";
  const name = file.name || file.original_name || "";
  return type.startsWith("image/") || /\.(png|jpe?g|gif|webp|svg|bmp|avif)$/i.test(name);
}

function createAttachmentPreview(file, url) {
  const preview = document.createElement("div");
  preview.className = "attachment-preview";

  if (isImageFile(file) && url) {
    const img = document.createElement("img");
    img.src = url;
    img.alt = file.name || "Attachment preview";
    img.loading = "lazy";
    preview.classList.add("image-preview");
    preview.appendChild(img);
    return preview;
  }

  preview.classList.add("doc-preview");
  preview.textContent = getFileExtension(file.name);
  return preview;
}

function iconTab(tabName) {
  document.querySelectorAll(".side-icon").forEach((btn) => btn.classList.toggle("active", btn.dataset.tab === tabName));
  $("#textPanel").classList.toggle("active-panel", tabName === "text");
  $("#filesPanel").classList.toggle("active-panel", tabName === "files");
}

document.querySelectorAll(".side-icon").forEach((btn) => {
  btn.addEventListener("click", () => iconTab(btn.dataset.tab));
});

// Firestore listener only reflects saved text from other users/devices.
onSnapshot(textDocRef, (snapshot) => {
  if (isSavingText) return;
  const data = snapshot.data();
  textArea.value = data?.value || "";
  requestAnimationFrame(autoGrowTextArea);
}, (error) => {
  console.error(error);
  setStatus("Firebase error", "error");
});

saveTextBtn.addEventListener("click", async () => {
  isSavingText = true;
  saveTextBtn.disabled = true;
  setStatus("Saving...", "saving");

  try {
    await setDoc(textDocRef, {
      value: textArea.value,
      updatedAt: serverTimestamp()
    }, { merge: true });
    setStatus("Saved", "saved");
    hideStatusSoon();
  } catch (error) {
    console.error(error);
    setStatus("Save failed", "error");
    showToast(error.message || "Save failed");
  } finally {
    isSavingText = false;
    saveTextBtn.disabled = false;
  }
});

copyBtn.addEventListener("click", async () => {
  await navigator.clipboard.writeText(textArea.value || "");
  showToast("Text copied to clipboard");
});

clearTextBtn.addEventListener("click", async () => {
  if (!confirm("Clear shared text for everyone?")) return;
  clearTextBtn.disabled = true;
  setStatus("Clearing...", "saving");
  try {
    await setDoc(textDocRef, { value: "", updatedAt: serverTimestamp() }, { merge: true });
    textArea.value = "";
    autoGrowTextArea();
    setStatus("Cleared", "saved");
    hideStatusSoon();
    showToast("Text removed from Firebase");
  } catch (error) {
    console.error(error);
    setStatus("Clear failed", "error");
  } finally {
    clearTextBtn.disabled = false;
  }
});

requestAnimationFrame(autoGrowTextArea);

function setPendingFiles(files) {
  pendingFiles = files;
  if (!pendingFiles.length) {
    selectedFiles.innerHTML = "";
    return;
  }

  selectedFiles.innerHTML = `
    <strong>${pendingFiles.length} selected file${pendingFiles.length > 1 ? "s" : ""}</strong>
    <div class="selected-file-grid"></div>
  `;

  const grid = selectedFiles.querySelector(".selected-file-grid");
  pendingFiles.forEach((file) => {
    const item = document.createElement("div");
    item.className = "selected-file-item";

    const previewUrl = isImageFile(file) ? URL.createObjectURL(file) : "";
    const preview = createAttachmentPreview(file, previewUrl);
    if (previewUrl) {
      preview.querySelector("img")?.addEventListener("load", () => URL.revokeObjectURL(previewUrl), { once: true });
    }

    const details = document.createElement("div");
    details.className = "selected-file-details";
    details.innerHTML = `
      <span class="selected-file-name"></span>
      <small>${getFileExtension(file.name)} • ${bytesToSize(file.size)}</small>
    `;
    details.querySelector(".selected-file-name").textContent = file.name;

    item.append(preview, details);
    grid.appendChild(item);
  });
}

function uploadFileWithProgress(file, onProgress) {
  return new Promise((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    const formData = new FormData();
    formData.append("file", file);

    xhr.open("POST", "upload.php");

    xhr.upload.addEventListener("progress", (event) => {
      if (!event.lengthComputable) return;
      onProgress((event.loaded / event.total) * 100);
    });

    xhr.addEventListener("load", () => {
      try {
        const result = JSON.parse(xhr.responseText || "{}");
        if (xhr.status < 200 || xhr.status >= 300 || !result.success) {
          reject(new Error(result.message || "Upload failed"));
          return;
        }
        onProgress(100);
        resolve(result);
      } catch (error) {
        reject(new Error("Upload response was invalid"));
      }
    });

    xhr.addEventListener("error", () => reject(new Error("Network upload failed")));
    xhr.addEventListener("abort", () => reject(new Error("Upload cancelled")));
    xhr.send(formData);
  });
}

async function uploadFiles(files) {
  if (!files.length) return;
  saveFilesBtn.disabled = true;
  fileInput.disabled = true;
  setUploadStatus(`Uploading 0 of ${files.length} files...`, "saving");
  setUploadProgress(0, true);

  let uploadedCount = 0;
  let failedCount = 0;

  for (const file of files) {
    try {
      setUploadStatus(`Uploading ${uploadedCount + 1} of ${files.length}: ${file.name}`, "saving");

      const result = await uploadFileWithProgress(file, (filePercent) => {
        const overallPercent = ((uploadedCount + (filePercent / 100)) / files.length) * 100;
        setUploadProgress(overallPercent, true);
      });

      await addDoc(filesColRef, {
        name: result.original_name,
        savedName: result.saved_name,
        url: result.url,
        path: result.path,
        size: result.size,
        type: result.type,
        uploadedAt: serverTimestamp()
      });

      uploadedCount += 1;
      setUploadProgress((uploadedCount / files.length) * 100, true);
    } catch (error) {
      failedCount += 1;
      uploadedCount += 1;
      console.error(error);
      showToast(`${file.name}: ${error.message || "Upload failed"}`);
      setUploadProgress((uploadedCount / files.length) * 100, true);
    }
  }

  if (failedCount) {
    setUploadStatus(`${files.length - failedCount} saved, ${failedCount} failed`, "error");
  } else {
    setUploadStatus("Saved", "saved");
    fileInput.value = "";
    setPendingFiles([]);
    hideUploadProgressSoon();
  }

  saveFilesBtn.disabled = false;
  fileInput.disabled = false;
}

fileInput.addEventListener("change", (event) => setPendingFiles([...event.target.files]));
["dragenter", "dragover"].forEach((eventName) => {
  dropzone.addEventListener(eventName, (event) => {
    event.preventDefault();
    dropzone.classList.add("dragover");
  });
});
["dragleave", "drop"].forEach((eventName) => {
  dropzone.addEventListener(eventName, (event) => {
    event.preventDefault();
    dropzone.classList.remove("dragover");
  });
});
dropzone.addEventListener("drop", (event) => setPendingFiles([...event.dataTransfer.files]));
saveFilesBtn.addEventListener("click", () => uploadFiles(pendingFiles));

function renderEmptyState() {
  if (!fileList.children.length) {
    fileList.innerHTML = `<div class="empty">No saved attachments yet. Select files, then click Save Files.</div>`;
  }
}

function removeEmptyState() {
  const empty = fileList.querySelector(".empty");
  if (empty) empty.remove();
}

function renderFile(id, file) {
  removeEmptyState();
  const existing = renderedFiles.get(id);
  if (existing) existing.remove();

  const card = document.createElement("div");
  card.className = "file-card";
  card.dataset.id = id;

  const preview = createAttachmentPreview(file, file.url);

  const details = document.createElement("div");
  details.className = "file-details";
  details.innerHTML = `
    <div class="file-name"></div>
    <div class="file-meta">${getFileExtension(file.name)} • ${bytesToSize(file.size)} • ${file.type || "file"}</div>
  `;
  details.querySelector(".file-name").textContent = file.name;

  const actions = document.createElement("div");
  actions.className = "file-actions";
  actions.innerHTML = `
    <a href="${file.url}" target="_blank" rel="noopener">Open</a>
    <a href="${file.url}" download>Download</a>
    <button type="button">Delete</button>
  `;
  actions.querySelector("button").addEventListener("click", () => deleteFile(id, file));

  card.append(preview, details, actions);
  fileList.prepend(card);
  renderedFiles.set(id, card);
}

async function deleteFile(id, file) {
  if (!confirm(`Delete ${file.name}?`)) return;
  const formData = new FormData();
  formData.append("saved_name", file.savedName || "");
  formData.append("path", file.path || "");

  const response = await fetch("delete_attachment.php", { method: "POST", body: formData });
  const result = await response.json();
  if (!result.success) {
    showToast(result.message || "Delete failed");
    return;
  }
  await deleteDoc(doc(db, "internal_share", "attachments", "items", id));
  showToast("Attachment removed");
}

onSnapshot(query(filesColRef, orderBy("uploadedAt", "desc")), (snapshot) => {
  if (snapshot.empty) {
    fileList.innerHTML = "";
    renderedFiles.clear();
    renderEmptyState();
    return;
  }

  snapshot.docChanges().forEach((change) => {
    const id = change.doc.id;
    if (change.type === "removed") {
      const card = renderedFiles.get(id);
      if (card) card.remove();
      renderedFiles.delete(id);
      renderEmptyState();
    } else {
      renderFile(id, change.doc.data());
    }
  });
}, (error) => {
  console.error(error);
  setUploadStatus("Firebase error", "error");
});

clearFilesBtn.addEventListener("click", async () => {
  if (!confirm("Delete all attachments from the assets folder and Firebase?")) return;
  clearFilesBtn.disabled = true;
  setUploadStatus("Clearing...", "saving");
  setUploadProgress(0, false);

  try {
    const snapshot = await getDocs(filesColRef);
    const files = snapshot.docs.map(docSnap => docSnap.data());

    const response = await fetch("clear_attachments.php", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ files })
    });
    const result = await response.json();
    if (!result.success) throw new Error(result.message || "Clear failed");

    await Promise.all(snapshot.docs.map(docSnap => deleteDoc(docSnap.ref)));
    setUploadStatus("Cleared", "saved");
    hideUploadProgressSoon();
    showToast("All attachments removed");
  } catch (error) {
    console.error(error);
    setUploadStatus("Clear failed", "error");
    showToast(error.message || "Clear failed");
  } finally {
    clearFilesBtn.disabled = false;
  }
});
